import subprocess
from tqdm import tqdm
from multiprocessing import Process

def run(qubtis_num, target_file, output_file):
    command = ['python', 'Zeus.py', '-n', str(qubtis_num), '-s', 'quantum_program', '-r', '10', '-m', '50', target_file]

    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

    with open(output_file, "w") as file:
        file.write(result.stdout)
        file.write(result.stderr)


if __name__ == "__main__":
    target_file = "example/exp_1_s/quantum_program_0.py"
    output_file = "output.txt"
    run(1,target_file, output_file)