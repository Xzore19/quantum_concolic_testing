from qiskit import Aer, transpile
import math

def check_state_eq(qc, target_probability, delta):
    state_len = len(target_probability)
    qubits_num = int(math.log(state_len, 2))
    qubits_state = [bin(i)[2:].zfill(qubits_num) for i in range(state_len)]
    qc.measure_all()
    simulator = Aer.get_backend('aer_simulator')
    compiled_circuit = transpile(qc, simulator)
    job = simulator.run(compiled_circuit, shots=10000).result().get_counts()
    target = True
    for i in range(state_len):
        print(job.get(qubits_state[i], 0)/10000)
        if (job.get(qubits_state[i], 0)/10000) < target_probability[i]-delta or (job.get(qubits_state[i], 0) / 10000)> target_probability[i]+delta:
            target = False
    return target


def quantum_program(x, qc):
    qc.ccx(2, 1, 0)
    qc.iswap(1, 0)
    qc.ccx(2, 1, 0)
    qc.x(2)
    qc.crz(0.7853981633974483, 1, 2)

    if x == -14:
        qc.swap(1, 0)
        qc.cz(1, 2)
        qc.cx(2, 1)

        if check_state_eq(qc, [0.2483, 0.1702, 0.009, 0.0155, 0.0457, 0.2724, 0.0354, 0.2035], 0.01):
            return 1
        else:
            return 2
    else:
        qc.cx(2, 1)
        qc.z(2)
        qc.tdg(2)

        if check_state_eq(qc, [0.0185, 0.0739, 0.0391, 0.1187, 0.227, 0.0436, 0.2787, 0.2006], 0.01):
            return 3
        else:
            return 4

def expected_result():
    return [1, 2, 3, 4]
    