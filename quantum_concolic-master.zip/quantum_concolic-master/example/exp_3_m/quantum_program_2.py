
from qiskit import Aer, transpile
import math

def check_state_eq(qc, target_probability, delta):
    state_len = len(target_probability)
    qubits_num = int(math.log(state_len, 2))
    qubits_state = [bin(i)[2:].zfill(qubits_num) for i in range(state_len)]
    qc.measure_all()
    simulator = Aer.get_backend('aer_simulator')
    compiled_circuit = transpile(qc, simulator)
    job = simulator.run(compiled_circuit, shots=10000).result().get_counts()
    target = True
    for i in range(state_len):
        print(job.get(qubits_state[i], 0)/10000)
        if (job.get(qubits_state[i], 0)/10000) < target_probability[i]-delta or (job.get(qubits_state[i], 0) / 10000)> target_probability[i]+delta:
            target = False
    return target


def quantum_program(x, qc):
    a = 0
    qc.rz(3.141592653589793, 1)
    qc.cz(0, 2)
    qc.x(1)
    qc.iswap(2, 0)

    if x == 0:
        a = 1
        qc.cz(0, 2)
        x += 4
        qc.rz(1.5707963267948966, 1)
        qc.iswap(2, 0)
        qc.ccz(2, 1, 0)

    elif x <= 8:
        a = 2
        qc.iswap(2, 1)

    else:
        a = 3
        qc.iswap(1, 0)
        qc.z(1)
        qc.x(0)
        qc.t(0)
        qc.y(1)

    if check_state_eq(qc, [0.0221, 0.1765, 0.152, 0.1592, 0.1311, 0.1128, 0.1753, 0.0709], 0.01):
        return a
    else:
        return a+3

def expected_result():
    return [1,2,3,4,5,6]
    