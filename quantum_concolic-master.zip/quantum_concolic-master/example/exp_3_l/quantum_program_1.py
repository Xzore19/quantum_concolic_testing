
from qiskit import Aer, transpile
import math

def check_state_lt(qc, target_probability, delta):
    qc.measure_all()
    simulator = Aer.get_backend('aer_simulator')
    compiled_circuit = transpile(qc, simulator)
    job = simulator.run(compiled_circuit, shots=10000).result().get_counts()
    new_job = {}
    for i in job.keys():
        new_job[int(i, 2)] = job[i]
    target = True
    for [target_state, prob] in target_probability:
        if (new_job.get(target_state, 0) / 10000) > prob + delta:
            target = False
    return target


def quantum_program(x, qc):
    qc.z(2)
    qc.crx(0.7853981633974483, 2, 1)
    qc.cp(1.5707963267948966, 2, 0)
    qc.cry(0.7853981633974483, 2, 0)
    qc.cswap(2, 1, 0)
    x *= 1
    qc.crz(0.7853981633974483, 1, 2)
    qc.h(1)
    x -= 10
    qc.cswap(2, 1, 0)

    if x >= 0:
        qc.iswap(2, 1)
        qc.iswap(2, 0)
        qc.x(2)
        qc.ccz(2, 1, 0)
        qc.z(1)
        qc.x(0)
        qc.h(0)
        qc.csx(1, 0)
        qc.swap(2, 0)

        if check_state_lt(qc, [[0, 0.0744], [2, 0.0937], [1, 0.1144], [4, 0.0815]], 0.005):
            return 1
        else:
            return 2
    else:
        qc.x(1)
        x //= 6
        qc.sxdg(1)
        qc.h(1)
        qc.cx(2, 0)
        qc.ccz(2, 1, 0)
        qc.rz(0.7853981633974483, 0)
        qc.ccz(2, 1, 0)
        qc.crz(1.5707963267948966, 1, 0)
        qc.rx(0.39269908169872414, 2)
        qc.h(0)

        if check_state_lt(qc, [[5, 0.1112], [2, 0.2161]], 0.005):
            return 3
        else:
            return 4

def expected_result():
    return [1, 2, 3, 4]
    