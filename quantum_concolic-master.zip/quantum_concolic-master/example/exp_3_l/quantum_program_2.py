
from qiskit import Aer, transpile
import math

def check_state_eq(qc, target_probability, delta):
    state_len = len(target_probability)
    qubits_num = int(math.log(state_len, 2))
    qubits_state = [bin(i)[2:].zfill(qubits_num) for i in range(state_len)]
    qc.measure_all()
    simulator = Aer.get_backend('aer_simulator')
    compiled_circuit = transpile(qc, simulator)
    job = simulator.run(compiled_circuit, shots=10000).result().get_counts()
    target = True
    for i in range(state_len):
        print(job.get(qubits_state[i], 0)/10000)
        if (job.get(qubits_state[i], 0)/10000) < target_probability[i]-delta or (job.get(qubits_state[i], 0) / 10000)> target_probability[i]+delta:
            target = False
    return target


def quantum_program(x, qc):
    a = 0
    qc.cz(1, 2)
    qc.iswap(1, 0)
    qc.x(1)
    qc.iswap(1, 0)
    qc.cz(1, 2)
    qc.swap(2, 0)
    qc.cswap(2, 1, 0)
    qc.ccz(2, 1, 0)

    if x <= -15:
        a = 1
        qc.ccx(2, 1, 0)
        qc.ccz(2, 1, 0)
        qc.h(0)
        qc.rx(0.7853981633974483, 1)
        qc.cswap(2, 1, 0)
        qc.rx(0.39269908169872414, 2)
        qc.cx(2, 1)

    elif x < -12:
        a = 2
        qc.ch(2, 0)
        qc.cp(0.39269908169872414, 1, 0)
        qc.x(1)
        qc.crz(0.7853981633974483, 1, 0)
        qc.rz(1.5707963267948966, 0)

    else:
        a = 3

    if check_state_eq(qc, [0.0575, 0.2059, 0.1485, 0.0521, 0.1392, 0.2331, 0.0776, 0.0861], 0.01):
        return a
    else:
        return a+3

def expected_result():
    return [1,2,3,4,5,6]
    