from optparse import OptionParser 
import os
import sys
from concolic.loader import loaderFactory, generate_quantum_version
from concolic.explore import ExplorationEngine
import time

print("Quantum Concolic with dreal")

usage = "usage: %prog [options] <path to a *.py file>"
parser = OptionParser(usage=usage)

parser.add_option("-s", "--start", dest="entry", action="store", help="Specify entry point", default="")
parser.add_option("-n", "--number", dest="qbit_num", type="int", help="Circuit qubit number", default=3)
parser.add_option("-m", "--max-iters", dest="max_iters", type="int", help="Run specified number of iterations", default=0)
parser.add_option("-r", "--repeat", dest="repeat_times", type="int", help="Exection repeated times", default=10)

(options, args) = parser.parse_args()

filename = os.path.abspath(args[0])


new_filename = generate_quantum_version(filename, options.entry)
app = loaderFactory(new_filename, "", options.qbit_num)

if app == None:
    sys.exit(1)

print("Exploring.......................")

result = None

solver = "z3"

try:
    engine = ExplorationEngine(funcinv=app.createInvocation(), solver=solver, repeated_times=options.repeat_times)

    expected_result =  app.get_expected_result()
    engine.expected = expected_result
    start_zeus = time.time()
    generatedInputs, returnVals, path = engine.explore(options.max_iters)
    result = app.executionComplete(returnVals)
    finish_zeus = time.time()
    print("Finish Time:",finish_zeus-start_zeus)


except ImportError:
    sys.exit(1)

if result is None or result == True:
    sys.exit(0)
else:
    sys.exit(1)
