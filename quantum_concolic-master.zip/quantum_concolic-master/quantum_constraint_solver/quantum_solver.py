import ast
from z3 import And, Not
from quantum_constraint_solver.symqv.expressions.qbit import Qbits
from quantum_constraint_solver.symqv.models.circuit import Circuit
from quantum_constraint_solver.qiskit_plugin import operations_to_program
from quantum_constraint_solver.symqv.expressions.complex import Complexes


def eq_constraint(prob_constraint, symbolic_state_list, circuit):
    for index, prob in enumerate(prob_constraint):
        target_state = symbolic_state_list[index]
        circuit.solver.add(target_state.r ** 2 + target_state.i ** 2 == prob)
    return circuit

def neq_constraint(prob_constraint, symbolic_state_list, circuit):
    for index, prob in enumerate(prob_constraint):
        target_state = symbolic_state_list[index]
        circuit.solver.add(target_state.r ** 2 + target_state.i ** 2 != prob)
    return circuit

def gt_constraint(prob_constraint, symbolic_state_list, circuit):
    # prob_constraint: [[state1, prob1],[state2, prob2]...]
    for single in prob_constraint:
        target_state = symbolic_state_list[single[0]]
        circuit.solver.add(target_state.r ** 2 + target_state.i ** 2 > single[1])
    return circuit

def lt_constraint(prob_constraint, symbolic_state_list, circuit):
    # prob_constraint: [[state1, prob1],[state2, prob2]...]
    for single in prob_constraint:
        target_state = symbolic_state_list[single[0]]
        circuit.solver.add(target_state.r ** 2 + target_state.i ** 2 < single[1])
    return circuit

def quantum_constraint_solver(num_qbits, operations, prob_constraint, flag, unaccepted_results=None):
    qbit_name = [f"q{i}" for i in range(num_qbits)]
    symbolic_qubit_list = Qbits(qbit_name)
    num_operations = len(operations)

    # generate symbolic circuit
    circuit = Circuit(symbolic_qubit_list, program=operations_to_program(num_qbits, operations))

    circuit.initialize([None for i in range(num_qbits)])
    final_state_list = [f"psi_{num_operations}_{i}" for i in range(2 ** num_qbits)]
    initial_state_list = [f"psi_{0}_{i}" for i in range(2 ** num_qbits)]

    symbolic_initial_state = Complexes(initial_state_list)
    symbolic_state_list = Complexes(final_state_list)

    if flag == "==":
        circuit = eq_constraint(prob_constraint, symbolic_state_list, circuit)
    elif flag == "!=":
        circuit = neq_constraint(prob_constraint, symbolic_state_list, circuit)
    elif flag == ">":
        circuit = gt_constraint(prob_constraint, symbolic_state_list, circuit)
    elif flag == "<":
        circuit = lt_constraint(prob_constraint, symbolic_state_list, circuit)

    
    if unaccepted_results != None:
        for un_result in unaccepted_results:
            constraint = []
            for key in symbolic_initial_state:
                temp_result_r = un_result[str(key.r)+" "]
                temp_result_i = un_result[str(key.i)+" "]
                if type(temp_result_r).__name__ == "list":
                    constraint.append(And(key.r > temp_result_r[0], key.r < temp_result_r[1]))
                else:
                    constraint.append(Not(key.r == temp_result_r))
                if type(temp_result_i).__name__ == "list":
                    constraint.append(And(key.i > temp_result_i[0], key.i < temp_result_i[1]))
                else:
                    constraint.append(Not(key.i == temp_result_i))
            circuit.solver.add(Not(And(constraint)))

    result, time_full = circuit.prove(overapproximation=False)


    if result == "unsat":
        return "can not solve", _, _

    output = result.stdout.decode("utf-8")
    quantum_result = output.replace("define-fun", "").replace("() Real", "!").split("\n")[2:-2]

    result_dict = {}
    for obj in quantum_result:
        state_name, state_value = obj.split("!")
        state_name, state_value = state_name[4:], ast.literal_eval(state_value[1:-1])
        if state_name[4] == "0":
            result_dict[state_name] = state_value

    result_state = []
    for state_obj in initial_state_list:
        temp1, temp2 = result_dict.get(state_obj + ".r "), result_dict.get(state_obj + ".i ")
        if type(temp1).__name__ == "list":
            temp1 = temp1[0]
        if type(temp2).__name__ == "list":
            temp2 = temp2[0]
        result_state.append(complex(temp1, temp2))

    return result_state, time_full, result_dict


if __name__ == "__main__":
    result, time, _ = quantum_constraint_solver(2, ["csx(1,0)", "x(0)", "cry(4.3225, 1, 0)"], [[3, 0.5272]], flag=">")
    print(result)