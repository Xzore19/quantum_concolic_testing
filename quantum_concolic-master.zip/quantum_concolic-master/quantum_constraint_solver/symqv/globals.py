precision_format = '{:.4f}'
