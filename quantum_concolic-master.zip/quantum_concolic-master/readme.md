## Installation

There are three requirements to run. The Python packages are:

- z3-solver (for SMT sort declaration and syntax generation)
- pyparsing (needed for output parsing)
- numpy (for arithmetic)
- scipy (for optimization)

Also, the system runs on requires [dReal](http://dreal.github.io) to be installed and added to the path
in order for the solver to work.

Install Python packages:

    pip install z3-solver
    pip install pyparsing
    pip install numpy
    pip install scipy

Install dReal on Ubuntu:

    # 20.04
    sudo apt-get install curl
    curl -fsSL https://raw.githubusercontent.com/dreal/dreal4/master/setup/ubuntu/20.04/install.sh | sudo bash
    
    # 18.04
    sudo apt-get install curl
    curl -fsSL https://raw.githubusercontent.com/dreal/dreal4/master/setup/ubuntu/18.04/install.sh | sudo bash

Alternatively, make the shell script `install.sh` executable and run it:

    sudo chmod +x install.sh
    ./install.sh

## Examples

    python Zeus.py -n #qubit_num  -s quantum_program  -r #repeat_time -m #max_iteration
