from collections import deque
from concolic.path_to_constraint import PathToConstraint
from concolic.symbolic_types import symbolic_type
from concolic.symbolic_types import SymbolicType
from quantum_constraint_solver.quantum_solver import quantum_constraint_solver
from concolic.z3_wrap import Z3Wrapper
import re
import time
import subprocess
import random

bin_op = {"==": "!=", "!=": "==", ">": "<", "<": ">"}


class ExplorationEngine:
    def __init__(self, funcinv, solver="z3", repeated_times=10):
        self.invocation = funcinv
        self.symbolic_inputs = {}
        self.repeated_times = repeated_times
        self.expected = None
        for n in funcinv.getNames():
            self.symbolic_inputs[n] = funcinv.createArgumentValue(n)

        self.constraint_to_solve = deque([])
        self.num_processed_constraints = 0

        self.path = PathToConstraint(lambda c: self.addConstraint(c))

        symbolic_type.SymbolicObject.SI = self.path

        self.solver = Z3Wrapper()

        # outputs
        self.generated_inputs = []
        self.execution_return_values = []

        self.start_time = time.time()

    def addConstraint(self, constraint):
        self.constraint_to_solve.append(constraint)
        constraint.inputs = self._getInputs()

    def _getInputs(self):
        return self.symbolic_inputs.copy()

    def _setInputs(self, d):
        self.symbolic_inputs = d

    def _getConcrValue(self, v):
        if isinstance(v, SymbolicType):
            return v.getConcrValue()
        else:
            return v

    def _recordInputs(self):
        args = self.symbolic_inputs
        inputs = [(k, self._getConcrValue(args[k])) for k in args]
        self.generated_inputs.append(inputs)
        print(inputs)
        if "qc" in self.symbolic_inputs.keys():
            print("qc-state:", self.symbolic_inputs["qc"].state)

    def _oneExecution(self, expected_path=None):
        self._recordInputs()
        self.path.reset(expected_path)

        for exe_num in range(self.repeated_times):
            if "qc" in self.symbolic_inputs.keys():
                self.symbolic_inputs["qc"].gates = []
            ret = self.invocation.callFunction(self.symbolic_inputs)
            # print("-------------------------------(Result:", ret, ")-------------------------------")
            if ret not in self.execution_return_values:
                # self.execution_return_values.append(ret)
                new_result_time = time.time()
                print("---------------------------(Time:", new_result_time-self.start_time, ")-------------")
                print("-------------------------------(New Result:", ret, ")-------------------------------")
                if expected_path:
                    expected_path.unaccepted_results = []
                break

        self.execution_return_values.append(ret)

    def _isExplorationComplete(self):
        num_constr = len(self.constraint_to_solve)
        if num_constr == 0:
            return True
        else:
            return False

    def _updateSymbolicParameter(self, name, val):
        self.symbolic_inputs[name] = self.invocation.createArgumentValue(name, val)

    def explore(self, max_iterations=0):
        self._oneExecution()
        exec_dict = {}

        iterations = 1
        if max_iterations != 0 and iterations >= max_iterations:
            return self.execution_return_values


        while not self._isExplorationComplete():
            selected = self.constraint_to_solve.popleft()

            if selected.processed:
                continue
            self._setInputs(selected.inputs)

            asserts, query = selected.getAssertsAndQuery()

            if query.getVars() == ["qc"]:
                qc_constraint = str(query)
                flag, gates, target_prob = process_qc_constraint(qc_constraint)
                exec_str = str(flag)+str(gates)+str(target_prob)
                exec_list = exec_dict.get(exec_str, [])
                # print("explore.py Now we use quantum solver!!!!!!!!!!!")
                try:
                    result, time, result_dict = quantum_constraint_solver(self.symbolic_inputs["qc"].qubits_num, \
                                                                            gates, \
                                                                            target_prob, \
                                                                            flag, \
                                                                            unaccepted_results=exec_dict.get(exec_str, None))
                    if result_dict not in exec_list:
                        exec_list.append(result_dict)
                    exec_dict[exec_str] = exec_list
                except subprocess.TimeoutExpired as e:
                    state_num = pow(2, self.symbolic_inputs["qc"].qubits_num)
                    complex_num = [complex(random.uniform(-1, 1), random.uniform(-1, 1)) for i in range(state_num)]
                    abs_complex = [abs(i) for i in complex_num]
                    result = [i / sum(abs_complex) for i in complex_num]
                model = {"qc": result}
            else:
                model = self.solver.findCounterexample(asserts, query)

            if model == None:
                continue
            else:
                for name in model.keys():
                    self._updateSymbolicParameter(name, model[name])
            
            self._oneExecution(expected_path=selected)
            iterations += 1

            self.num_processed_constraints += 1

            if set(self.execution_return_values) == set(self.expected):
                break

            if max_iterations != 0 and iterations >= max_iterations:
                break
        
        return self.generated_inputs, self.execution_return_values, self.path


def process_qc_constraint(qc_constraint):
    if "False" in qc_constraint:
        flag = qc_constraint.split("{")[0][1:]
    else:
        flag = bin_op[qc_constraint.split("{")[0][1:]]


    if flag == "==" or flag == "!=":
        matches = re.findall(r'\[[^\]]*\]', qc_constraint)
        gates = eval(matches[0])
        target_prob = eval(matches[-1])
    elif flag == ">" or flag == "<":
        matches = re.findall(r'\[[^\]]*\]', qc_constraint)
        gates = eval(matches[0])
        target_prob = []
        for i in matches[2:]:
            i = i.replace("[[", "[")
            target_prob.append(eval(i))
    return flag, gates, target_prob
