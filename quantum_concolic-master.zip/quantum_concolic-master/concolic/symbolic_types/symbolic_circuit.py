from typing import Optional

from concolic.symbolic_types.symbolic_int import SymbolicObject, SymbolicInteger
from qiskit import QuantumCircuit, Aer, transpile
import numpy as np
import math
import traceback


class NewQuantumCircuit(QuantumCircuit):
    def __init__(self, qubits_num, repeat=10000):
        QuantumCircuit.__init__(self, qubits_num)
        self.repeat = repeat

    def check_state_eq(self, target_probability, delta=0.01):
        state_len = len(target_probability)
        qubits_num = int(math.log(state_len, 2))
        qubits_state = [bin(i)[2:].zfill(qubits_num) for i in range(state_len)]
        self.measure_all()
        simulator = Aer.get_backend('aer_simulator')
        compiled_circuit = transpile(self, simulator)
        job = simulator.run(compiled_circuit, shots=self.repeat).result().get_counts()
        target = True
        for i in range(state_len):
            if (job.get(qubits_state[i], 0) / self.repeat) < target_probability[i] - delta or \
                    (job.get(qubits_state[i], 0) / self.repeat) > target_probability[i] + delta:
                target = False
        return target

    def check_state_gt(self, target_probability, delta=0.01):
        self.measure_all()
        simulator = Aer.get_backend('aer_simulator')
        compiled_circuit = transpile(self, simulator)
        job = simulator.run(compiled_circuit, shots=self.repeat).result().get_counts()
        new_job = {}
        for i in job.keys():
            new_job[int(i, 2)] = job[i]
        target = True
        for [target_state, prob] in target_probability:
            if (new_job.get(target_state, 0) / self.repeat) < prob - delta:
                target = False
        return target

    def check_state_lt(self, target_probability, delta=0.01):
        self.measure_all()
        simulator = Aer.get_backend('aer_simulator')
        compiled_circuit = transpile(self, simulator)
        job = simulator.run(compiled_circuit, shots=self.repeat).result().get_counts()
        new_job = {}
        for i in job.keys():
            new_job[int(i, 2)] = job[i]
        target = True
        for [target_state, prob] in target_probability:
            if (new_job.get(target_state, 0) / self.repeat) > prob + delta:
                target = False
        return target
    
    def usr_defined(self):
        pass


class SymbolicCircuit(SymbolicObject, NewQuantumCircuit):
    def __init__(self, name, value, expr=None):
        value /= np.linalg.norm(value)
        self.state = value
        self.qubits_num = int(math.log(len(self.state),2))
        SymbolicObject.__init__(self, name, expr)
        NewQuantumCircuit.__init__(self, self.qubits_num)
        self.initialize(self.state)
        self.name = name
        self.gates = []

    def getConcrValue(self):
        qc = NewQuantumCircuit(self.qubits_num)
        qc.initialize(self.state)
        for gate in self.gates:
            eval("qc."+gate)
        return qc

    def __str__(self):
        return self.name

    def wrap(conc, sym):
        return SymbolicCircuit("se", conc, sym)

    def cx(self, *args):
        trace = traceback.extract_stack()[-2]
        self.gates.append(trace.line[3:])
        super(SymbolicObject, self).cx(*args)
        # print(self.gates)

    def check_state_eq(self, target_probability, delta=0.01):
        return self._op_worker([self, str(target_probability)], \
                               lambda x, y: x.check_state_eq(eval(y), delta), \
                               op="=={%s}" % str(self.gates))
    
    def check_state_gt(self, target_probability, delta=0.01):
        return self._op_worker([self, str(target_probability)], \
                               lambda x, y: x.check_state_gt(eval(y), delta), \
                               op=">{%s}" % str(self.gates))
    
    def check_state_lt(self, target_probability, delta=0.01):
        return self._op_worker([self, str(target_probability)], \
                               lambda x, y: x.check_state_lt(eval(y), delta), \
                               op="<{%s}" % str(self.gates))

    def _op_worker(self, args, fun, op):
        return self._do_sexpr(args, fun, op, SymbolicInteger.wrap)


ops = ["h", "x", "ccx", "ccz", "s", "z", "y", "sdg", "t", "tdg", "ch", "u" \
                                                                       "cnot", "cs", "cz", "csdg", "p", "cp", "rx",
       "crx", "ry", "cu", \
       "cry", "rz", "crz", "swap", "iswap", "cswap", "sx", "sxdg", "csx"]


def make_method(method):
    code = "def %s(self, *args):\n" % method
    code += "   trace = traceback.extract_stack()[-2]\n"
    code += "   self.gates.append(trace.line[3:])\n"
    code += "   super(SymbolicObject, self).%s(*args)\n" % method
    # code += "   print(self.gates)"
    locals_dict = {}
    exec(code, globals(), locals_dict)
    setattr(SymbolicCircuit, method, locals_dict[method])


for gate in ops:
    make_method(gate)
