import functools
import inspect
import traceback


class SymbolicType(object):
    def __init__(self, name, expr=None):
        self.name = name
        self.expr = expr


    def getConcrValue(self):
        raise NotImplemented()

    def wrap(conc, sym):
        raise NotImplemented()

    def isVariable(self):
        return self.expr == None

    def unwrap(self):
        if self.isVariable():
            return (self.getConcrValue(), self)
        else:
            return (self.getConcrValue(), self.expr)

    def getVars(self):
        if self.isVariable():
            return [self.name]
        elif isinstance(self.expr, list):
            return self._getVarsLeaves(self.expr)
        else:
            return []


    def _getVarsLeaves(self, l):
        if isinstance(l, list):
            return functools.reduce(lambda a, x: self._getVarsLeaves(x) + a, l, [])
        elif isinstance(l, SymbolicType):
            return [l.name]
        else:
            return []

    def _do_sexpr(self, args, fun, op, wrap):
        unwrapped = [(a.unwrap() if isinstance(a, SymbolicType) else (a,a)) for a in args]

        args = zip(inspect.getfullargspec(fun).args, [c for (c,s) in unwrapped])

        concrete = fun(**dict([a for a in args]))

        symbolic = [ op ] + [ s for (c,s) in unwrapped]

        return wrap(concrete, symbolic)

    def symbolicEq(self, other):
        if not isinstance(other, SymbolicType):
            return False
        if self.isVariable() or other.isVariable():
            return self.name == other.name
        return self._eq_worker(self.expr, other.expr)

    def _eq_worker(self, expr1, expr2):
        if type(expr1) != type(expr2):
            return False
        if isinstance(expr1, list):
            return len(expr1) == len(expr2) and\
                type(expr1[0]) == type(expr2[0]) and\
                all([self._eq_worker(x,y) for x,y in zip(expr1[1:], expr2[1:])])
        elif isinstance(expr1, SymbolicType):
            return expr1.name == expr2.name
        else:
            return expr1 == expr2

    def toString(self):
        if self.isVariable():
            if type(self).__name__ == "SymbolicCircuit":
                return self.name + "#" + str(self.state)+"|"
            else:
                return self.name + "#" + str(self.getConcrValue())
        else:
            return self._toString(self.expr)

    def _toString(self, expr):
        if isinstance(expr, list):
            return "(" + expr[0] + " " + ", ".join([self._toString(a) for a in expr[1:]]) + ")"
        elif isinstance(expr, SymbolicType):
            return expr.toString()
        else:
            return str(expr)

class SymbolicObject(SymbolicType, object):

    SI = None

    def __init__(self, name, expr=None):
        SymbolicType.__init__(self,name, expr)

    def wrap(conc, sym):
        raise NotImplemented()


    def __bool__(self):
        ret = bool(self.getConcrValue())
        if SymbolicObject.SI != None:
            SymbolicObject.SI.whichBranch(ret, self)
        return ret

    def _do_bin_op(self, other, fun, op, wrap):
        return self._do_sexpr([self, other], fun, op, wrap)

    def __eq__(self, other):
        return self._do_bin_op(other, lambda x, y: x == y, "==", SymbolicObject.wrap)

    def __ne__(self, other):
        return self._do_bin_op(other, lambda x, y: x != y, "!=", SymbolicObject.wrap)

    def __lt__(self, other):
        return self._do_bin_op(other, lambda x, y: x < y, "<", SymbolicObject.wrap)

    def __le__(self, other):
        return self._do_bin_op(other, lambda x, y: x <= y, "<=", SymbolicObject.wrap)

    def __gt__(self, other):
        return self._do_bin_op(other, lambda x, y: x > y, ">", SymbolicObject.wrap)

    def __ge__(self, other):
        return self._do_bin_op(other, lambda x, y: x >= y, ">=", SymbolicObject.wrap)






