from concolic.constraint import Constraint
from concolic.predicate import Predicate


class PathToConstraint:
    def __init__(self, add):
        self.constraint = {}
        self.add = add
        self.root_constraint = Constraint(None, None)
        self.current_constraint = self.root_constraint
        self.expected_path = None

    def reset(self, expected):
        self.current_constraint = self.root_constraint
        if expected == None:
            self.expected_path = None
        else:
            self.expected_path = []
            tmp = expected
            while tmp.predicate is not None:
                self.expected_path.append(tmp.predicate)
                tmp = tmp.parent

    def whichBranch(self, branch, symbolic_type):
        p = Predicate(symbolic_type, branch)
        p.negate()
        cneg = self.current_constraint.findChild(p)
        p.negate()
        c = self.current_constraint.findChild(p)

        if c is None:
            c = self.current_constraint.addChild(p)
            self.add(c)

        if self.expected_path != None and self.expected_path != []:
            expected = self.expected_path.pop()
            done = self.expected_path == []


        if cneg is not None:

            cneg.processed = True
            c.processed = True

        self.current_constraint = c








