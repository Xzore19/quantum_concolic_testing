import inspect  # 函数监控器
import os
import sys
import re
from concolic.invocation import FunctionInvocation
from concolic.symbolic_types import SymbolicInteger, getSymbolic, SymbolicCircuit


class Loader:
    def __init__(self, filename, entry, qbit_num):
        self._fileName = os.path.basename(filename)
        self._fileName = self._fileName[:-3]
        if (entry == ""):
            self._entryPoint = self._fileName
        else:
            self._entryPoint = entry
        self._resetCallback(True)
        self.qbit_num = qbit_num

    def _resetCallback(self, firstpass=False):
        self.app = None
        if firstpass and self._fileName in sys.modules:
            print("There already is a module loaded named " + self._fileName)
            raise ImportError()
        try:
            if (not firstpass and self._fileName in sys.modules):
                del (sys.modules[self._fileName])

            self.app = __import__(self._fileName)

            if not self._entryPoint in self.app.__dict__ or not callable(self.app.__dict__[self._entryPoint]):
                print("File " + self._fileName + ".py doesn't contain a function named " + self._entryPoint)
                raise ImportError()
        except Exception as arg:
            print("Couldn't import " + self._fileName)
            print(arg)
            raise ImportError()

    def getFile(self):
        return self._fileName

    def getEntry(self):
        return self._entryPoint

    def _execute(self, **args):
        return self.app.__dict__[self._entryPoint](**args)
    
    def get_expected_result(self):
        return self.app.__dict__["expected_result"]()

    def executionComplete(self, return_vals):
        if "expected_result" in self.app.__dict__:
            return self._check(return_vals, self.app.__dict__["expected_result"]())
        if "expected_result_set" in self.app.__dict__:
            return self._check(return_vals, self.app.__dict__["expected_result_set"](), False)
        else:
            print(self._fileName + ".py contains no expected_result function")
            return None

    def _check(self, computed, expected, as_bag=True):
        b_c = self._toBag(computed)
        b_e = self._toBag(expected)
        if as_bag and b_c.keys() != b_e.keys() or not as_bag and set(computed) != set(expected):
            print("-------------------> Target program test failed <---------------------")
            print("Expected: %s, found: %s" % (b_e.keys(), b_c.keys()))
            return False
        else:
            print("Target program test passed <---")
            return True

    def _toBag(self, l):
        bag = {}
        for i in l:
            if i in bag:
                bag[i] += 1
            else:
                bag[i] = 1
        return bag

    def createInvocation(self):
        inv = FunctionInvocation(self._execute, self._resetCallback)
        func = self.app.__dict__[self._entryPoint]

        argspec = inspect.getfullargspec(func)

        if "concrete_args" in func.__dict__:
            for (f, v) in func.concrete_args.items():
                if not f in argspec.args:
                    print("Error in @concrete: " + self._entryPoint + " has no argument named " + f)
                    raise ImportError()
                else:
                    Loader._initializeArgumentConcrete(inv, f, v)

        if "symbolic_args" in func.__dict__:
            for (f, v) in func.symbolic_args.items():
                if not f in argspec.args:
                    print("Error (@symbolic): " + self._entryPoint + " has no argument named " + f)
                    raise ImportError()
                elif f in inv.getNames():
                    print("Argument " + f + " defined in both @concrete and @symbolic")
                    raise ImportError()
                else:
                    s = getSymbolic(v)
                    if (s == None):
                        print(
                            "Error at argument " + f + " of entry point " + self._entryPoint + " : no corresponding symbolic type found for type " + str(
                                type(v)))
                        raise ImportError()
                    Loader._initializeArgumentSymbolic(inv, f, v, s)


        for a in argspec.args:
            if not a in inv.getNames():
                if a == "qc":
                    initial_state = [1] + [0 for i in range(2 ** self.qbit_num - 1)]
                    Loader._initializeArgumentSymbolic(inv, a, initial_state, SymbolicCircuit)
                else:
                    Loader._initializeArgumentSymbolic(inv, a, 0, SymbolicInteger)
        return inv

    def _initializeArgumentConcrete(inv, f, val):
        inv.addArgumentConstructor(f, val, lambda n, v: val)

    def _initializeArgumentSymbolic(inv, f, val, st):
        inv.addArgumentConstructor(f, val, lambda n, v: st(n, v))


def loaderFactory(filename, entry, qbit_num):
    if not os.path.isfile(filename) or not re.search(".py$", filename):
        print("Please provide a Python file to load")
        return None
    try:
        dir = os.path.dirname(filename)
        sys.path = [dir] + sys.path
        ret = Loader(filename, entry, qbit_num)
        return ret
    except ImportError:
        sys.path = sys.path[1:]
        return None


def generate_quantum_version(filename, entry):
    quantum_code = ""
    _fileName = os.path.basename(filename)
    _fileName = _fileName[:-3]
    if (entry == ""):
        _entryPoint = _fileName
    else:
        _entryPoint = entry
    with open(filename, "r") as program_file:
        for line in program_file:
            if _entryPoint in line:
                line = line.replace(_entryPoint, "new_quantum")
            if "check_state_eq" in line and "def" not in line:
                pattern = r"check_state_eq\(([^)]+), \[([^]]+)\], ([^)]+)\)"
                replacement = r"\1.check_state_eq([\2],\3)"
                line = re.sub(pattern, replacement, line)
            if "check_state_gt" in line and "def" not in line:
                line = line.replace("qc, ", "")
                line = line.replace("check_state_gt", "qc.check_state_gt")
            if "check_state_lt" in line and "def" not in line:
                line = line.replace("qc, ", "")
                line = line.replace("check_state_lt", "qc.check_state_lt")
            quantum_code += line
    with open("test/temp_file/new_quantum.py", "w+") as temp_file:
        temp_file.write(quantum_code)
    return "test/temp_file/new_quantum.py"
